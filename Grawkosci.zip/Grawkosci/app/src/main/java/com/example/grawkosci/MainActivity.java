package com.example.grawkosci;

import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int rSum = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void Roll(View a) {



        TextView tv = findViewById(R.id.roll);
        TextView tvSum = findViewById(R.id.rollSum);

        Random random = new Random();


        int rzut1 = random.nextInt(6) + 1;
        int rzut2 = random.nextInt(6) + 1;
        int rzut3 = random.nextInt(6) + 1;
        int rzut4 = random.nextInt(6) + 1;
        int rzut5 = random.nextInt(6) + 1;
        int rzut6 = random.nextInt(6) + 1;

        int sumR = rzut1 + rzut2 + rzut3 + rzut4 + rzut5 + rzut6;

        rSum += sumR;

        tv.setText(Integer.toString(sumR));
        tvSum.setText(Integer.toString(rSum));




        setDiceImage(findViewById(R.id.k1), rzut1);
        setDiceImage(findViewById(R.id.k2), rzut2);
        setDiceImage(findViewById(R.id.k3), rzut3);
        setDiceImage(findViewById(R.id.k4), rzut4);
        setDiceImage(findViewById(R.id.k5), rzut5);
        setDiceImage(findViewById(R.id.k6), rzut6);
    }

    private void setDiceImage(ImageView imageView, int value) {

        switch (value) {
            case 1:
                imageView.setImageResource(R.drawable.kosc1);
                break;
            case 2:
                imageView.setImageResource(R.drawable.kosc2);
                break;
            case 3:
                imageView.setImageResource(R.drawable.kosc3);
                break;
            case 4:
                imageView.setImageResource(R.drawable.kosc4);
                break;
            case 5:
                imageView.setImageResource(R.drawable.kosc5);
                break;
            case 6:
                imageView.setImageResource(R.drawable.kosc6);
                break;
        }
    }
}